# 🎟 Movie Ticket Booking & Recommendation System

A desktop **Java Swing** application for browsing movies, booking seats, and getting
personalized recommendations — built with a layered, object-oriented architecture and
persistent local storage.

## ✨ Features

- **User & Admin roles** — separate login flows with hashed (SHA-256) passwords
- **Visual seat map** — color-coded seat grid (available / selected / booked), not just checkboxes
- **Search & filter movies** by genre or language
- **Dynamic pricing** — weekend surcharge + optional student discount
- **Booking management** — view booking history and cancel bookings (seats are released back)
- **Genre-based recommendation engine** — suggests movies from your booking history, falling
  back to top-rated movies for new users
- **Admin analytics dashboard** — total revenue, active vs. cancelled bookings, most-booked movie
- **Persistent storage** — all data (users, movies, bookings) is saved to disk and reloaded on
  the next launch, so nothing is lost when the app closes
- **Input validation & custom exceptions** — duplicate email checks, invalid input handling

## 🏗 Architecture

The project follows a simple layered structure instead of one giant file:

```
src/movieapp/
├── model/       → Person, User, Admin, Movie, Booking (data classes)
├── service/      → PasswordUtil, RecommendationSystem, DataStore, custom exceptions
├── gui/          → MovieBookingGUI (Swing UI, wires everything together)
└── Main.java     → application entry point
```

## 🖥 Tech Stack

- **Java 17+** (Swing for the UI)
- **Java Object Serialization** for lightweight local persistence — no external database
  setup required to run the project
- **SHA-256** password hashing

## 🚀 Getting Started

```bash
# Compile
javac -d out $(find src -name "*.java")

# Run
java -cp out movieapp.Main
```

On first run the app preloads a sample movie catalog. An admin account is available by
default:
- **Email:** admin@movie.com
- **Password:** admin123

## 📌 Possible Next Steps

- Move persistence to a real database (SQLite/MySQL via JDBC)
- Add multiple showtimes per movie with independent seat maps
- Package as a runnable `.jar` with `jpackage`
- Rebuild the UI as a web app (Spring Boot + React) for multi-user concurrent access

## 📄 License

This project is open for learning and portfolio use.
