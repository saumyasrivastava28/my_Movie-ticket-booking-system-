package movieapp.gui;

import movieapp.model.*;
import movieapp.service.*;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.List;
import java.util.*;

public class MovieBookingGUI extends JFrame {

    private static final Color BG = new Color(24, 26, 32);
    private static final Color PANEL_BG = new Color(34, 37, 46);
    private static final Color ACCENT = new Color(229, 9, 20);   // cinematic red
    private static final Color ACCENT_SOFT = new Color(255, 193, 7);
    private static final Color TEXT = new Color(235, 235, 235);
    private static final Color SEAT_FREE = new Color(76, 175, 80);
    private static final Color SEAT_BOOKED = new Color(120, 120, 120);
    private static final Color SEAT_SELECTED = new Color(255, 193, 7);
    private static final Font TITLE_FONT = new Font("Segoe UI", Font.BOLD, 20);
    private static final Font BASE_FONT = new Font("Segoe UI", Font.PLAIN, 14);

    private final List<User> users;
    private final List<Movie> movies;
    private final Admin admin = new Admin("Admin", "admin@movie.com", PasswordUtil.hash("admin123"));
    private User currentUser;

    public MovieBookingGUI() {
        DataStore.SavedData saved = DataStore.load();
        if (saved != null) {
            users = saved.users;
            movies = saved.movies;
        } else {
            users = new ArrayList<>();
            movies = new ArrayList<>();
            preloadMovies();
        }

        setTitle("🎟 Movie Ticket Booking & Recommendation System");
        setSize(680, 560);
        setMinimumSize(new Dimension(560, 480));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(BG);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                DataStore.save(users, movies);
            }
        });

        showWelcomeScreen();
    }

    // ---------- Styling helpers ----------

    private JButton styledButton(String text, Color bg) {
        JButton b = new JButton(text);
        b.setFont(BASE_FONT);
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(10, 14, 10, 14));
        return b;
    }

    private JLabel headerLabel(String text) {
        JLabel l = new JLabel(text, JLabel.CENTER);
        l.setFont(TITLE_FONT);
        l.setForeground(TEXT);
        l.setBorder(new EmptyBorder(12, 8, 12, 8));
        return l;
    }

    private JPanel basePanel(int rows) {
        JPanel p = new JPanel(new GridLayout(rows, 1, 10, 10));
        p.setBackground(BG);
        p.setBorder(new EmptyBorder(20, 40, 20, 40));
        return p;
    }

    private void refresh(JPanel panel) {
        getContentPane().removeAll();
        add(panel);
        revalidate();
        repaint();
    }

    // ---------- Screens ----------

    private void showWelcomeScreen() {
        currentUser = null;
        JPanel panel = basePanel(5);
        panel.add(headerLabel("🎬 Movie Ticket Booking & Recommendation System"));
        JButton register = styledButton("Register", ACCENT);
        JButton userLogin = styledButton("Login as User", ACCENT);
        JButton adminLogin = styledButton("Login as Admin", PANEL_BG);
        JButton exit = styledButton("Exit", PANEL_BG);

        panel.add(register);
        panel.add(userLogin);
        panel.add(adminLogin);
        panel.add(exit);

        register.addActionListener(e -> registerUser());
        userLogin.addActionListener(e -> userLogin());
        adminLogin.addActionListener(e -> adminLogin());
        exit.addActionListener(e -> {
            DataStore.save(users, movies);
            System.exit(0);
        });

        refresh(panel);
    }

    private void registerUser() {
        JTextField name = new JTextField();
        JTextField email = new JTextField();
        JPasswordField pass = new JPasswordField();
        Object[] fields = {"Name:", name, "Email:", email, "Password:", pass};
        int res = JOptionPane.showConfirmDialog(this, fields, "Register", JOptionPane.OK_CANCEL_OPTION);
        if (res != JOptionPane.OK_OPTION) return;

        try {
            if (name.getText().trim().isEmpty() || !email.getText().contains("@")) {
                throw new InvalidBookingException("Please enter a valid name and email.");
            }
            for (User u : users) {
                if (u.getEmail().equalsIgnoreCase(email.getText().trim())) {
                    throw new DuplicateUserException("An account with this email already exists.");
                }
            }
            users.add(new User(name.getText().trim(), email.getText().trim(),
                    PasswordUtil.hash(new String(pass.getPassword()))));
            DataStore.save(users, movies);
            JOptionPane.showMessageDialog(this, "Registration Successful!");
        } catch (DuplicateUserException | InvalidBookingException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Registration Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void userLogin() {
        JTextField email = new JTextField();
        JPasswordField pass = new JPasswordField();
        Object[] fields = {"Email:", email, "Password:", pass};
        int res = JOptionPane.showConfirmDialog(this, fields, "User Login", JOptionPane.OK_CANCEL_OPTION);
        if (res != JOptionPane.OK_OPTION) return;

        String enteredPass = new String(pass.getPassword());
        for (User u : users) {
            if (u.getEmail().equalsIgnoreCase(email.getText().trim())
                    && PasswordUtil.matches(enteredPass, u.getPasswordHash())) {
                currentUser = u;
                showUserMenu();
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Invalid credentials!", "Login Failed", JOptionPane.ERROR_MESSAGE);
    }

    private void adminLogin() {
        JTextField email = new JTextField();
        JPasswordField pass = new JPasswordField();
        Object[] fields = {"Email:", email, "Password:", pass};
        int res = JOptionPane.showConfirmDialog(this, fields, "Admin Login", JOptionPane.OK_CANCEL_OPTION);
        if (res != JOptionPane.OK_OPTION) return;

        if (email.getText().trim().equalsIgnoreCase(admin.getEmail())
                && PasswordUtil.matches(new String(pass.getPassword()), admin.getPasswordHash())) {
            showAdminMenu();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid admin credentials!", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showUserMenu() {
        JPanel panel = basePanel(7);
        panel.add(headerLabel("Welcome, " + currentUser.getName() + " 👋"));
        JButton viewMovies = styledButton("View / Search Movies", PANEL_BG);
        JButton bookTicket = styledButton("Book Ticket", ACCENT);
        JButton viewBookings = styledButton("My Bookings", PANEL_BG);
        JButton recs = styledButton("Recommended For You", ACCENT_SOFT);
        JButton logout = styledButton("Logout", PANEL_BG);

        panel.add(viewMovies);
        panel.add(bookTicket);
        panel.add(viewBookings);
        panel.add(recs);
        panel.add(logout);

        viewMovies.addActionListener(e -> searchAndDisplayMovies());
        bookTicket.addActionListener(e -> bookTicket());
        viewBookings.addActionListener(e -> showBookings());
        recs.addActionListener(e -> showRecommendations());
        logout.addActionListener(e -> {
            DataStore.save(users, movies);
            showWelcomeScreen();
        });

        refresh(panel);
    }

    private void showAdminMenu() {
        JPanel panel = basePanel(6);
        panel.add(headerLabel("🛠 Admin Panel"));
        JButton addMovie = styledButton("Add Movie", ACCENT);
        JButton viewMovies = styledButton("View Movies", PANEL_BG);
        JButton deleteMovie = styledButton("Delete Movie", PANEL_BG);
        JButton report = styledButton("Revenue & Analytics", ACCENT_SOFT);
        JButton back = styledButton("Logout", PANEL_BG);

        panel.add(addMovie);
        panel.add(viewMovies);
        panel.add(deleteMovie);
        panel.add(report);
        panel.add(back);

        addMovie.addActionListener(e -> addMovie());
        viewMovies.addActionListener(e -> searchAndDisplayMovies());
        deleteMovie.addActionListener(e -> deleteMovie());
        report.addActionListener(e -> showAdminReport());
        back.addActionListener(e -> {
            DataStore.save(users, movies);
            showWelcomeScreen();
        });

        refresh(panel);
    }

    // ---------- Movies ----------

    private void searchAndDisplayMovies() {
        String query = JOptionPane.showInputDialog(this,
                "Filter by genre or language (leave blank to see all):", "Search Movies",
                JOptionPane.PLAIN_MESSAGE);
        List<Movie> results = new ArrayList<>();
        for (Movie m : movies) {
            if (query == null || query.trim().isEmpty()
                    || m.getGenre().toLowerCase().contains(query.trim().toLowerCase())
                    || m.getLanguage().toLowerCase().contains(query.trim().toLowerCase())) {
                results.add(m);
            }
        }
        StringBuilder sb = new StringBuilder();
        if (results.isEmpty()) {
            sb.append("No movies match that filter.");
        } else {
            for (Movie m : results) {
                sb.append(m).append("  |  Seats left: ").append(m.getAvailableSeatCount()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(this, sb.toString(), "Available Movies", JOptionPane.INFORMATION_MESSAGE);
    }

    private void addMovie() {
        JTextField title = new JTextField();
        JTextField genre = new JTextField();
        JTextField rating = new JTextField();
        JTextField lang = new JTextField();
        JTextField price = new JTextField("200");
        Object[] fields = {"Title:", title, "Genre:", genre, "Rating (0-10):", rating,
                "Language:", lang, "Base Price (₹):", price};
        int res = JOptionPane.showConfirmDialog(this, fields, "Add Movie", JOptionPane.OK_CANCEL_OPTION);
        if (res != JOptionPane.OK_OPTION) return;

        try {
            double r = Double.parseDouble(rating.getText().trim());
            double p = Double.parseDouble(price.getText().trim());
            if (title.getText().trim().isEmpty()) throw new NumberFormatException();
            movies.add(new Movie(title.getText().trim(), genre.getText().trim(), r, lang.getText().trim(), p));
            DataStore.save(users, movies);
            JOptionPane.showMessageDialog(this, "Movie Added Successfully!");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid title, rating and price.",
                    "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteMovie() {
        if (movies.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No movies to delete.");
            return;
        }
        String[] titles = movies.stream().map(Movie::getTitle).toArray(String[]::new);
        String selected = (String) JOptionPane.showInputDialog(this, "Choose a movie to remove:",
                "Delete Movie", JOptionPane.PLAIN_MESSAGE, null, titles, titles[0]);
        if (selected == null) return;
        movies.removeIf(m -> m.getTitle().equals(selected));
        DataStore.save(users, movies);
        JOptionPane.showMessageDialog(this, "Movie removed.");
    }

    // ---------- Booking ----------

    private void bookTicket() {
        if (movies.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No movies available right now.");
            return;
        }
        String[] titles = movies.stream().map(Movie::getTitle).toArray(String[]::new);
        String selected = (String) JOptionPane.showInputDialog(this, "Choose a movie:", "Book Ticket",
                JOptionPane.PLAIN_MESSAGE, null, titles, titles[0]);
        if (selected == null) return;
        Movie movie = movies.stream().filter(m -> m.getTitle().equals(selected)).findFirst().orElse(null);
        if (movie == null) return;

        String[] theatres = {"PVR Cinemas", "Omaxe Mall", "Grand Venice Mall", "Cinepolis"};
        String theatre = (String) JOptionPane.showInputDialog(this, "Select Theatre:", "Choose Theatre",
                JOptionPane.PLAIN_MESSAGE, null, theatres, theatres[0]);
        if (theatre == null) return;

        String[] showTimes = {"11:00 AM", "2:30 PM", "6:00 PM", "9:30 PM"};
        String show = (String) JOptionPane.showInputDialog(this, "Select Show Time:", "Show Time",
                JOptionPane.PLAIN_MESSAGE, null, showTimes, showTimes[0]);
        if (show == null) return;

        List<String> selectedSeats = pickSeats(movie);
        if (selectedSeats == null || selectedSeats.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No seats selected!");
            return;
        }

        String[] payments = {"Credit/Debit Card", "UPI", "Cash"};
        String payment = (String) JOptionPane.showInputDialog(this, "Select Payment Method:", "Payment",
                JOptionPane.PLAIN_MESSAGE, null, payments, payments[0]);

        double price = selectedSeats.size() * movie.getBasePrice();
        // Weekend surcharge for a touch of dynamic pricing
        Calendar cal = Calendar.getInstance();
        int day = cal.get(Calendar.DAY_OF_WEEK);
        if (day == Calendar.SATURDAY || day == Calendar.SUNDAY) {
            price *= 1.15;
        }

        String studentID = JOptionPane.showInputDialog("Enter Student ID (optional for 10% discount):");
        if (studentID != null && !studentID.trim().isEmpty()) {
            price *= 0.9;
            JOptionPane.showMessageDialog(this, "10% Student Discount Applied!");
        }

        Booking booking = new Booking(movie, show, selectedSeats, theatre, payment, Math.round(price * 100.0) / 100.0);
        currentUser.addBooking(booking);
        DataStore.save(users, movies);
        JOptionPane.showMessageDialog(this, "✅ Booking Confirmed!\n\n" + booking);
    }

    /** Visual seat map: green = free, gray = booked, yellow = selected. */
    private List<String> pickSeats(Movie movie) {
        JPanel seatPanel = new JPanel(new GridLayout(3, 6, 8, 8));
        seatPanel.setBackground(PANEL_BG);
        seatPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        Map<String, JToggleButton> seatButtons = new LinkedHashMap<>();

        for (Map.Entry<String, Boolean> entry : movie.getSeats().entrySet()) {
            JToggleButton seatBtn = new JToggleButton(entry.getKey());
            boolean booked = entry.getValue();
            seatBtn.setEnabled(!booked);
            seatBtn.setBackground(booked ? SEAT_BOOKED : SEAT_FREE);
            seatBtn.setForeground(Color.WHITE);
            seatBtn.setOpaque(true);
            seatBtn.setBorderPainted(false);
            seatBtn.addItemListener(e ->
                    seatBtn.setBackground(seatBtn.isSelected() ? SEAT_SELECTED : SEAT_FREE));
            seatButtons.put(entry.getKey(), seatBtn);
            seatPanel.add(seatBtn);
        }

        JPanel wrapper = new JPanel(new BorderLayout(0, 8));
        wrapper.add(new JLabel("🟩 Available   🟨 Selected   ⬜ Booked", JLabel.CENTER), BorderLayout.NORTH);
        wrapper.add(seatPanel, BorderLayout.CENTER);

        int res = JOptionPane.showConfirmDialog(this, wrapper, "Select Seats", JOptionPane.OK_CANCEL_OPTION);
        if (res != JOptionPane.OK_OPTION) return null;

        List<String> selected = new ArrayList<>();
        for (Map.Entry<String, JToggleButton> entry : seatButtons.entrySet()) {
            if (entry.getValue().isSelected()) {
                selected.add(entry.getKey());
                movie.getSeats().put(entry.getKey(), true);
            }
        }
        return selected;
    }

    private void showBookings() {
        if (currentUser.getBookings().isEmpty()) {
            JOptionPane.showMessageDialog(this, "No bookings yet!");
            return;
        }
        StringBuilder sb = new StringBuilder();
        for (Booking b : currentUser.getBookings()) sb.append(b).append("\n\n");
        JOptionPane.showMessageDialog(this, sb.toString(), "Your Bookings", JOptionPane.INFORMATION_MESSAGE);

        int cancelChoice = JOptionPane.showConfirmDialog(this, "Would you like to cancel a booking?",
                "Cancel Booking", JOptionPane.YES_NO_OPTION);
        if (cancelChoice != JOptionPane.YES_OPTION) return;

        List<Booking> active = new ArrayList<>();
        for (Booking b : currentUser.getBookings()) {
            if (b.getStatus().equals("CONFIRMED")) active.add(b);
        }
        if (active.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No active bookings to cancel.");
            return;
        }
        String[] ids = active.stream().map(b -> "#" + b.getId() + " - " + b.getMovie().getTitle())
                .toArray(String[]::new);
        String chosen = (String) JOptionPane.showInputDialog(this, "Select booking to cancel:", "Cancel Booking",
                JOptionPane.PLAIN_MESSAGE, null, ids, ids[0]);
        if (chosen == null) return;
        int idx = Arrays.asList(ids).indexOf(chosen);
        active.get(idx).cancel();
        DataStore.save(users, movies);
        JOptionPane.showMessageDialog(this, "Booking cancelled and seats released.");
    }

    private void showRecommendations() {
        List<Movie> rec = RecommendationSystem.recommend(currentUser, movies);
        StringBuilder sb = new StringBuilder("Recommended Movies:\n");
        for (Movie m : rec) sb.append("- ").append(m).append("\n");
        JOptionPane.showMessageDialog(this, sb.toString(), "Recommendations", JOptionPane.INFORMATION_MESSAGE);
    }

    // ---------- Admin analytics ----------

    private void showAdminReport() {
        double totalRevenue = 0;
        Map<String, Integer> bookingCountByMovie = new HashMap<>();
        int activeBookings = 0, cancelledBookings = 0;

        for (User u : users) {
            for (Booking b : u.getBookings()) {
                if (b.getStatus().equals("CONFIRMED")) {
                    totalRevenue += b.getTotalAmount();
                    activeBookings++;
                    bookingCountByMovie.merge(b.getMovie().getTitle(), 1, Integer::sum);
                } else {
                    cancelledBookings++;
                }
            }
        }

        String topMovie = bookingCountByMovie.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("N/A");

        String report = String.format(
                "📊 Revenue & Analytics\n\n" +
                        "Registered Users: %d\n" +
                        "Total Movies Listed: %d\n" +
                        "Active Bookings: %d\n" +
                        "Cancelled Bookings: %d\n" +
                        "Total Revenue: ₹%.2f\n" +
                        "Most Booked Movie: %s",
                users.size(), movies.size(), activeBookings, cancelledBookings, totalRevenue, topMovie);

        JOptionPane.showMessageDialog(this, report, "Admin Report", JOptionPane.INFORMATION_MESSAGE);
    }

    // ---------- Seed data ----------

    private void preloadMovies() {
        movies.add(new Movie("Inception", "Sci-Fi", 8.8, "English", 220));
        movies.add(new Movie("3 Idiots", "Comedy", 8.5, "Hindi", 180));
        movies.add(new Movie("Avengers", "Action", 8.4, "English", 250));
        movies.add(new Movie("Bahubali", "Action", 8.0, "Telugu", 200));
        movies.add(new Movie("Yeh Jawaani Hai Deewani", "Romance", 8.9, "Hindi", 190));
        movies.add(new Movie("Om Shanti Om", "Romantic/Musical", 8.9, "Hindi", 190));
        movies.add(new Movie("Sitaramam", "Romantic", 8.9, "Hindi", 190));
        movies.add(new Movie("Shinchan: Spicy Kasukabe Dancers", "Animation", 7.5, "Hindi", 150));
    }
}
