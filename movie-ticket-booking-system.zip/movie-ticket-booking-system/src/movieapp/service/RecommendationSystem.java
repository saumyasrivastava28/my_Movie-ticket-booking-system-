package movieapp.service;

import movieapp.model.Movie;
import movieapp.model.User;

import java.util.ArrayList;
import java.util.List;

public class RecommendationSystem {

    /**
     * Recommends movies matching the user's previously booked genres.
     * Falls back to the top-rated movies if the user has no booking history yet.
     */
    public static List<Movie> recommend(User user, List<Movie> allMovies) {
        List<Movie> recommendations = new ArrayList<>();
        for (Movie m : allMovies) {
            if (user.getPreferredGenres().contains(m.getGenre())) {
                recommendations.add(m);
            }
        }
        if (recommendations.isEmpty()) {
            List<Movie> sorted = new ArrayList<>(allMovies);
            sorted.sort((a, b) -> Double.compare(b.getRating(), a.getRating()));
            return sorted.subList(0, Math.min(3, sorted.size()));
        }
        return recommendations;
    }
}
