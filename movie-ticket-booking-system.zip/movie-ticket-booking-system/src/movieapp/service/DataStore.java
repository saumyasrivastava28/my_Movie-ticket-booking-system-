package movieapp.service;

import movieapp.model.Movie;
import movieapp.model.User;

import java.io.*;
import java.util.List;

/**
 * Saves and loads all application data to a local file so bookings and
 * accounts survive an app restart. Uses Java serialization for simplicity —
 * no external database driver or setup required to run the project.
 */
public class DataStore {
    private static final String FILE_NAME = "moviedata.ser";

    public static void save(List<User> users, List<Movie> movies) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            out.writeObject(new SavedData(users, movies));
        } catch (IOException e) {
            System.err.println("Could not save data: " + e.getMessage());
        }
    }

    public static SavedData load() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return null;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (SavedData) in.readObject();
        } catch (Exception e) {
            System.err.println("Could not load saved data, starting fresh: " + e.getMessage());
            return null;
        }
    }

    public static class SavedData implements Serializable {
        private static final long serialVersionUID = 1L;
        public final List<User> users;
        public final List<Movie> movies;

        public SavedData(List<User> users, List<Movie> movies) {
            this.users = users;
            this.movies = movies;
        }
    }
}
