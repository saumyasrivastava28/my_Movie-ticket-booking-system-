package movieapp.service;

import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;

/**
 * Simple SHA-256 password hashing so plain-text passwords are never stored.
 * (For production use, a salted algorithm like BCrypt/Argon2 is recommended.)
 */
public class PasswordUtil {

    public static String hash(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : hashBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("Unable to hash password", e);
        }
    }

    public static boolean matches(String rawPassword, String hash) {
        return hash(rawPassword).equals(hash);
    }
}
