package movieapp.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class Booking implements Serializable {
    private static final long serialVersionUID = 1L;
    private static int counter = 1000;

    private final int id;
    private final Movie movie;
    private final String showTime;
    private final List<String> selectedSeats;
    private final String theatre;
    private final String paymentMethod;
    private final double totalAmount;
    private final Date bookedOn;
    private String status; // CONFIRMED or CANCELLED

    public Booking(Movie movie, String showTime, List<String> selectedSeats,
                    String theatre, String paymentMethod, double totalAmount) {
        this.id = counter++;
        this.movie = movie;
        this.showTime = showTime;
        this.selectedSeats = selectedSeats;
        this.theatre = theatre;
        this.paymentMethod = paymentMethod;
        this.totalAmount = totalAmount;
        this.bookedOn = new Date();
        this.status = "CONFIRMED";
    }

    public int getId() { return id; }
    public Movie getMovie() { return movie; }
    public List<String> getSelectedSeats() { return selectedSeats; }
    public double getTotalAmount() { return totalAmount; }
    public String getStatus() { return status; }

    public void cancel() {
        this.status = "CANCELLED";
        for (String seat : selectedSeats) {
            movie.getSeats().put(seat, false);
        }
    }

    @Override
    public String toString() {
        SimpleDateFormat fmt = new SimpleDateFormat("dd MMM yyyy, hh:mm a");
        return "Booking #" + id + " [" + status + "]\n" +
                "🎬 Movie: " + movie.getTitle() + "\n" +
                "Theatre: " + theatre + "\n" +
                "Show Time: " + showTime + "\n" +
                "Seats: " + selectedSeats + "\n" +
                "Payment Method: " + paymentMethod + "\n" +
                "Total Paid: ₹" + totalAmount + "\n" +
                "Booked On: " + fmt.format(bookedOn);
    }
}
