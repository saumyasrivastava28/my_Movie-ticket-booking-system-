package movieapp.model;

public class Admin extends Person {
    private static final long serialVersionUID = 1L;

    public Admin(String name, String email, String passwordHash) {
        super(name, email, passwordHash);
    }
}
