package movieapp.model;

import java.io.Serializable;

/**
 * Base class for anyone who can log into the system (User or Admin).
 */
public abstract class Person implements Serializable {
    private static final long serialVersionUID = 1L;

    protected String name;
    protected String email;
    protected String passwordHash; // never store plain-text passwords

    public Person(String name, String email, String passwordHash) {
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
    }

    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPasswordHash() { return passwordHash; }
}
