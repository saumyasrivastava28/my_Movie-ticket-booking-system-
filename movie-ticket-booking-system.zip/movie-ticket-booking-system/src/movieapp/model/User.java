package movieapp.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class User extends Person {
    private static final long serialVersionUID = 1L;

    private final List<Booking> bookings = new ArrayList<>();
    private final Set<String> preferredGenres = new HashSet<>();

    public User(String name, String email, String passwordHash) {
        super(name, email, passwordHash);
    }

    public void addBooking(Booking booking) {
        bookings.add(booking);
        preferredGenres.add(booking.getMovie().getGenre());
    }

    public void removeBooking(Booking booking) {
        bookings.remove(booking);
    }

    public List<Booking> getBookings() { return bookings; }
    public Set<String> getPreferredGenres() { return preferredGenres; }
}
