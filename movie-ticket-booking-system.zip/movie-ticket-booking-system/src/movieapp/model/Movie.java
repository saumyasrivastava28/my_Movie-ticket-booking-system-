package movieapp.model;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.Map;

public class Movie implements Serializable {
    private static final long serialVersionUID = 1L;
    private static int counter = 1;

    private final int id;
    private String title, genre, language;
    private double rating;
    private double basePrice;
    private final Map<String, Boolean> seats = new LinkedHashMap<>();

    public Movie(String title, String genre, double rating, String language, double basePrice) {
        this.id = counter++;
        this.title = title;
        this.genre = genre;
        this.rating = rating;
        this.language = language;
        this.basePrice = basePrice;

        // 3 rows x 6 seats = 18-seat mini theatre map
        String[] rows = {"A", "B", "C"};
        for (String row : rows) {
            for (int i = 1; i <= 6; i++) {
                seats.put(row + i, false);
            }
        }
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getGenre() { return genre; }
    public String getLanguage() { return language; }
    public double getRating() { return rating; }
    public double getBasePrice() { return basePrice; }
    public Map<String, Boolean> getSeats() { return seats; }

    public long getAvailableSeatCount() {
        return seats.values().stream().filter(booked -> !booked).count();
    }

    @Override
    public String toString() {
        return title + " (" + genre + ", " + language + ", ⭐" + rating + ", ₹" + basePrice + "/seat)";
    }
}
