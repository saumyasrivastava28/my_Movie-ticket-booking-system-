package movieapp;

import movieapp.gui.MovieBookingGUI;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MovieBookingGUI().setVisible(true));
    }
}
